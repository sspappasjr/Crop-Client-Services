const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 5001;
const DB_PATH = path.join(__dirname, 'cropclient.db');

// Middleware
app.use(cors());
app.use(bodyParser.json());

let db;

// Load database
async function loadDatabase() {
    const SQL = await initSqlJs();
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
    console.log('✓ Database loaded');
}

// Save database to disk
function saveDatabase() {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
}

// Helper to execute query and return results as JSON
function queryToJson(query, params = []) {
    const stmt = db.prepare(query);
    stmt.bind(params);
    const results = [];
    while (stmt.step()) {
        results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
}

// ==================== RANCHES ====================

// GET all ranches
app.get('/api/ranches', (req, res) => {
    try {
        const ranches = queryToJson('SELECT * FROM ranches ORDER BY ranch_name');
        res.json(ranches);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET single ranch
app.get('/api/ranches/:id', (req, res) => {
    try {
        const ranch = queryToJson('SELECT * FROM ranches WHERE ranch_id = ?', [req.params.id]);
        if (ranch.length === 0) {
            return res.status(404).json({ error: 'Ranch not found' });
        }
        res.json(ranch[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST new ranch
app.post('/api/ranches', (req, res) => {
    try {
        const { ranch_name, location, total_acres } = req.body;
        db.run('INSERT INTO ranches (ranch_name, location, total_acres) VALUES (?, ?, ?)',
            [ranch_name, location, total_acres]);
        saveDatabase();
        const newRanch = queryToJson('SELECT * FROM ranches WHERE ranch_id = last_insert_rowid()');
        res.status(201).json(newRanch[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT update ranch
app.put('/api/ranches/:id', (req, res) => {
    try {
        const { ranch_name, location, total_acres } = req.body;
        db.run('UPDATE ranches SET ranch_name = ?, location = ?, total_acres = ? WHERE ranch_id = ?',
            [ranch_name, location, total_acres, req.params.id]);
        saveDatabase();
        const updated = queryToJson('SELECT * FROM ranches WHERE ranch_id = ?', [req.params.id]);
        res.json(updated[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE ranch
app.delete('/api/ranches/:id', (req, res) => {
    try {
        db.run('DELETE FROM ranches WHERE ranch_id = ?', [req.params.id]);
        saveDatabase();
        res.json({ message: 'Ranch deleted', ranch_id: req.params.id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== LOTS ====================

// GET all lots or by ranch
app.get('/api/lots', (req, res) => {
    try {
        const { ranch_id } = req.query;
        let lots;
        if (ranch_id) {
            lots = queryToJson('SELECT * FROM lots WHERE ranch_id = ? ORDER BY lot_name', [ranch_id]);
        } else {
            lots = queryToJson('SELECT * FROM lots ORDER BY lot_name');
        }
        res.json(lots);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST new lot
app.post('/api/lots', (req, res) => {
    try {
        const { ranch_id, lot_name, acres, soil_type } = req.body;
        db.run('INSERT INTO lots (ranch_id, lot_name, acres, soil_type) VALUES (?, ?, ?, ?)',
            [ranch_id, lot_name, acres, soil_type]);
        saveDatabase();
        const newLot = queryToJson('SELECT * FROM lots WHERE lot_id = last_insert_rowid()');
        res.status(201).json(newLot[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== PLANTINGS ====================

// GET all plantings or by lot
app.get('/api/plantings', (req, res) => {
    try {
        const { lot_id } = req.query;
        let plantings;
        if (lot_id) {
            plantings = queryToJson('SELECT * FROM plantings WHERE lot_id = ? ORDER BY planting_name', [lot_id]);
        } else {
            plantings = queryToJson('SELECT * FROM plantings ORDER BY planting_name');
        }
        res.json(plantings);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST new planting
app.post('/api/plantings', (req, res) => {
    try {
        const { lot_id, planting_name, crop_type, plant_date, acres } = req.body;
        db.run('INSERT INTO plantings (lot_id, planting_name, crop_type, plant_date, acres) VALUES (?, ?, ?, ?, ?)',
            [lot_id, planting_name, crop_type, plant_date, acres]);
        saveDatabase();
        const newPlanting = queryToJson('SELECT * FROM plantings WHERE planting_id = last_insert_rowid()');
        res.status(201).json(newPlanting[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== IRRIGATIONS ====================

// GET all irrigations or by planting
app.get('/api/irrigations', (req, res) => {
    try {
        const { planting_id } = req.query;
        let irrigations;
        if (planting_id) {
            irrigations = queryToJson(
                'SELECT * FROM irrigations WHERE planting_id = ? ORDER BY irrigation_date DESC',
                [planting_id]
            );
        } else {
            irrigations = queryToJson('SELECT * FROM irrigations ORDER BY irrigation_date DESC');
        }
        res.json(irrigations);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST new irrigation
app.post('/api/irrigations', (req, res) => {
    try {
        const { planting_id, irrigation_date, water_inches, duration_hours, method, notes } = req.body;
        db.run(`INSERT INTO irrigations 
                (planting_id, irrigation_date, water_inches, duration_hours, method, notes) 
                VALUES (?, ?, ?, ?, ?, ?)`,
            [planting_id, irrigation_date, water_inches, duration_hours, method, notes]);
        saveDatabase();
        const newIrrigation = queryToJson('SELECT * FROM irrigations WHERE irrigation_id = last_insert_rowid()');
        res.status(201).json(newIrrigation[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT update irrigation
app.put('/api/irrigations/:id', (req, res) => {
    try {
        const { water_inches, duration_hours, method, notes } = req.body;
        db.run(`UPDATE irrigations 
                SET water_inches = ?, duration_hours = ?, method = ?, notes = ? 
                WHERE irrigation_id = ?`,
            [water_inches, duration_hours, method, notes, req.params.id]);
        saveDatabase();
        const updated = queryToJson('SELECT * FROM irrigations WHERE irrigation_id = ?', [req.params.id]);
        res.json(updated[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE irrigation
app.delete('/api/irrigations/:id', (req, res) => {
    try {
        db.run('DELETE FROM irrigations WHERE irrigation_id = ?', [req.params.id]);
        saveDatabase();
        res.json({ message: 'Irrigation deleted', irrigation_id: req.params.id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== STATISTICS ====================

// GET irrigation statistics
app.get('/api/irrigations/stats/:planting_id', (req, res) => {
    try {
        const stats = queryToJson(`
            SELECT 
                COUNT(*) as total_irrigations,
                SUM(water_inches) as total_water_inches,
                AVG(water_inches) as avg_water_inches,
                SUM(duration_hours) as total_hours,
                AVG(duration_hours) as avg_hours
            FROM irrigations 
            WHERE planting_id = ?
        `, [req.params.planting_id]);
        res.json(stats[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== SERVER STARTUP ====================

loadDatabase().then(() => {
    app.listen(PORT, () => {
        console.log(`✓ CropClient SQLite API running on http://localhost:${PORT}`);
        console.log('✓ Endpoints:');
        console.log('  - GET/POST /api/ranches');
        console.log('  - GET/POST /api/lots');
        console.log('  - GET/POST /api/plantings');
        console.log('  - GET/POST/PUT/DELETE /api/irrigations');
        console.log('  - GET /api/irrigations/stats/:planting_id');
    });
}).catch(err => {
    console.error('Failed to load database:', err);
});
