#!/usr/bin/env node

const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'cropclient.db');
let db;

// Load database
async function loadDatabase() {
    const SQL = await initSqlJs();
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
}

// Save database
function saveDatabase() {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
}

// Query helper
function queryToJson(query, params = []) {
    const stmt = db.prepare(query);
    stmt.bind(params);
    const results = [];
    while (stmt.step()) {
        results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
}

// MCP Tools
const tools = {
    // Get all ranches
    get_ranches: {
        description: "Get list of all ranches",
        handler: async () => {
            return queryToJson('SELECT * FROM ranches ORDER BY ranch_name');
        }
    },

    // Get lots for a ranch
    get_lots: {
        description: "Get lots for a ranch. Parameters: ranch_id (number)",
        handler: async (params) => {
            const { ranch_id } = params;
            return queryToJson('SELECT * FROM lots WHERE ranch_id = ? ORDER BY lot_name', [ranch_id]);
        }
    },

    // Get plantings for a lot
    get_plantings: {
        description: "Get plantings for a lot. Parameters: lot_id (number)",
        handler: async (params) => {
            const { lot_id } = params;
            return queryToJson('SELECT * FROM plantings WHERE lot_id = ? ORDER BY planting_name', [lot_id]);
        }
    },

    // Get irrigations
    get_irrigations: {
        description: "Get irrigation records. Parameters: planting_id (number, optional)",
        handler: async (params) => {
            const { planting_id } = params || {};
            if (planting_id) {
                return queryToJson(
                    'SELECT * FROM irrigations WHERE planting_id = ? ORDER BY irrigation_date DESC',
                    [planting_id]
                );
            }
            return queryToJson('SELECT * FROM irrigations ORDER BY irrigation_date DESC LIMIT 50');
        }
    },

    // Create irrigation record
    create_irrigation: {
        description: "Record new irrigation. Parameters: planting_id, irrigation_date, water_inches, duration_hours, method (optional), notes (optional)",
        handler: async (params) => {
            const { planting_id, irrigation_date, water_inches, duration_hours, method, notes } = params;
            
            db.run(`INSERT INTO irrigations 
                    (planting_id, irrigation_date, water_inches, duration_hours, method, notes) 
                    VALUES (?, ?, ?, ?, ?, ?)`,
                [planting_id, irrigation_date, water_inches, duration_hours, method || 'Drip', notes || '']);
            
            saveDatabase();
            
            const newRecord = queryToJson('SELECT * FROM irrigations WHERE irrigation_id = last_insert_rowid()');
            return {
                success: true,
                message: `Irrigation recorded: ${water_inches} inches for ${duration_hours} hours`,
                irrigation: newRecord[0]
            };
        }
    },

    // Update irrigation record
    update_irrigation: {
        description: "Update irrigation record. Parameters: irrigation_id, water_inches (optional), duration_hours (optional), method (optional), notes (optional)",
        handler: async (params) => {
            const { irrigation_id, water_inches, duration_hours, method, notes } = params;
            
            // Get current record
            const current = queryToJson('SELECT * FROM irrigations WHERE irrigation_id = ?', [irrigation_id]);
            if (current.length === 0) {
                return { success: false, error: 'Irrigation record not found' };
            }
            
            // Update with new values or keep current
            const newWater = water_inches !== undefined ? water_inches : current[0].water_inches;
            const newHours = duration_hours !== undefined ? duration_hours : current[0].duration_hours;
            const newMethod = method !== undefined ? method : current[0].method;
            const newNotes = notes !== undefined ? notes : current[0].notes;
            
            db.run(`UPDATE irrigations 
                    SET water_inches = ?, duration_hours = ?, method = ?, notes = ? 
                    WHERE irrigation_id = ?`,
                [newWater, newHours, newMethod, newNotes, irrigation_id]);
            
            saveDatabase();
            
            const updated = queryToJson('SELECT * FROM irrigations WHERE irrigation_id = ?', [irrigation_id]);
            return {
                success: true,
                message: 'Irrigation record updated',
                irrigation: updated[0]
            };
        }
    },

    // Get statistics
    get_irrigation_stats: {
        description: "Get irrigation statistics for a planting. Parameters: planting_id",
        handler: async (params) => {
            const { planting_id } = params;
            const stats = queryToJson(`
                SELECT 
                    COUNT(*) as total_irrigations,
                    SUM(water_inches) as total_water_inches,
                    AVG(water_inches) as avg_water_inches,
                    SUM(duration_hours) as total_hours,
                    AVG(duration_hours) as avg_hours
                FROM irrigations 
                WHERE planting_id = ?
            `, [planting_id]);
            
            return stats[0];
        }
    },

    // Read latest irrigation
    read_meter: {
        description: "Get the most recent irrigation record for a planting. Parameters: planting_id",
        handler: async (params) => {
            const { planting_id } = params;
            const latest = queryToJson(
                'SELECT * FROM irrigations WHERE planting_id = ? ORDER BY irrigation_date DESC LIMIT 1',
                [planting_id]
            );
            
            if (latest.length === 0) {
                return { message: 'No irrigation records found for this planting' };
            }
            
            return latest[0];
        }
    }
};

// MCP Protocol Handler
async function handleMCPRequest(request) {
    const { method, params } = request;

    if (method === 'tools/list') {
        return {
            tools: Object.keys(tools).map(name => ({
                name,
                description: tools[name].description,
                inputSchema: {
                    type: "object",
                    properties: {},
                    required: []
                }
            }))
        };
    }

    if (method === 'tools/call') {
        const { name, arguments: args } = params;
        const tool = tools[name];
        
        if (!tool) {
            return { error: `Unknown tool: ${name}` };
        }

        try {
            const result = await tool.handler(args || {});
            return {
                content: [{
                    type: "text",
                    text: JSON.stringify(result, null, 2)
                }]
            };
        } catch (error) {
            return {
                error: error.message,
                isError: true
            };
        }
    }

    return { error: `Unknown method: ${method}` };
}

// STDIO Protocol
process.stdin.setEncoding('utf8');
let buffer = '';

process.stdin.on('data', async (chunk) => {
    buffer += chunk;
    const lines = buffer.split('\n');
    buffer = lines.pop();

    for (const line of lines) {
        if (line.trim()) {
            try {
                const request = JSON.parse(line);
                const response = await handleMCPRequest(request);
                console.log(JSON.stringify(response));
            } catch (error) {
                console.log(JSON.stringify({ error: error.message }));
            }
        }
    }
});

// Initialize
loadDatabase().then(() => {
    console.error('✓ CropClient MCP Server ready');
    console.error('✓ Database loaded: cropclient.db');
    console.error('✓ Available tools:', Object.keys(tools).join(', '));
}).catch(err => {
    console.error('Failed to start MCP server:', err);
    process.exit(1);
});
