# CropClient Services - SQLite Edition

**Steve's Universal Hub Architecture with SQLite**

## What Is This?

Complete replacement for Sean's MongoDB system. Everything goes through the **SQLite API** - the single source of truth.

```
Natural Language (Gus/Phi-3 + MCP)
         ↓
    SQLite API (Port 5001)
         ↓
    SQLite Database (cropclient.db)
         ↓
    JSON (the fruit of the vine)
```

## Quick Start

```bash
# 1. Initialize database
npm run init

# 2. Start API server
npm run api

# 3. Test endpoints (in another terminal)
node test-api.js
```

## Architecture

### Files
- **cropclient.db** - SQLite database (portable, single file)
- **api-server.js** - REST API (replaces Sean's MongoDB API)
- **mcp-server.js** - Natural language interface for AI
- **init-database.js** - Database schema & sample data

### Database Schema

**ranches**
- ranch_id (PK)
- ranch_name
- location
- total_acres

**lots**
- lot_id (PK)
- ranch_id (FK)
- lot_name
- acres
- soil_type

**plantings**
- planting_id (PK)
- lot_id (FK)
- planting_name
- crop_type
- plant_date
- acres

**irrigations**
- irrigation_id (PK)
- planting_id (FK)
- irrigation_date
- water_inches
- duration_hours
- method
- notes

## API Endpoints

### Ranches
- `GET /api/ranches` - List all ranches
- `GET /api/ranches/:id` - Get single ranch
- `POST /api/ranches` - Create ranch
- `PUT /api/ranches/:id` - Update ranch
- `DELETE /api/ranches/:id` - Delete ranch

### Lots
- `GET /api/lots` - List all lots
- `GET /api/lots?ranch_id=1` - Lots for specific ranch
- `POST /api/lots` - Create lot

### Plantings
- `GET /api/plantings` - List all plantings
- `GET /api/plantings?lot_id=1` - Plantings for specific lot
- `POST /api/plantings` - Create planting

### Irrigations
- `GET /api/irrigations` - List all irrigations (last 50)
- `GET /api/irrigations?planting_id=1` - Irrigations for specific planting
- `POST /api/irrigations` - Create irrigation record
- `PUT /api/irrigations/:id` - Update irrigation
- `DELETE /api/irrigations/:id` - Delete irrigation
- `GET /api/irrigations/stats/:planting_id` - Get statistics

## MCP Tools (Natural Language)

When connected to Gus/Phi-3 or Claude, these tools enable natural language commands:

- **get_ranches** - "Show me all ranches"
- **get_lots** - "What lots are in ranch 1?"
- **get_plantings** - "Show plantings for lot 1"
- **get_irrigations** - "Show irrigation history for planting 1"
- **create_irrigation** - "Record 2.5 inches for 4 hours on field 1A"
- **update_irrigation** - "Change irrigation 5 to 3 inches"
- **get_irrigation_stats** - "What's the total water for planting 1?"
- **read_meter** - "What was the last irrigation for planting 1?"

## Example API Usage

### Create New Irrigation
```bash
curl -X POST http://localhost:5001/api/irrigations \
  -H "Content-Type: application/json" \
  -d '{
    "planting_id": 1,
    "irrigation_date": "2024-06-15",
    "water_inches": 2.5,
    "duration_hours": 4,
    "method": "Drip",
    "notes": "Regular irrigation"
  }'
```

### Get All Irrigations for a Planting
```bash
curl http://localhost:5001/api/irrigations?planting_id=1
```

### Get Statistics
```bash
curl http://localhost:5001/api/irrigations/stats/1
```

## MCP Server Configuration

Add to your MCP client config (e.g., Claude Desktop):

```json
{
  "mcpServers": {
    "cropclient-sqlite": {
      "command": "node",
      "args": ["/path/to/crop-client-services/mcp-server.js"]
    }
  }
}
```

## Why SQLite?

✅ **Portable** - Single file database, goes anywhere
✅ **Fast** - Faster than MongoDB for single-user scenarios
✅ **Universal** - Works on desktop, mobile, embedded
✅ **SQL** - Industry standard, everyone knows it
✅ **No Server** - No MongoDB daemon needed
✅ **Reliable** - Rock-solid, battle-tested
✅ **Free** - Public domain, zero cost

## Database Tools

### Desktop Management
- **DB Browser for SQLite** (recommended)
  - Download: https://sqlitebrowser.org/
  - Visual table designer
  - Query builder
  - Data browser

### CLI
```bash
# Install sqlite3 CLI
sudo apt install sqlite3

# Open database
sqlite3 cropclient.db

# Run queries
sqlite> SELECT * FROM ranches;
sqlite> .tables
sqlite> .schema irrigations
```

## Migration from MongoDB

This system provides the **exact same API** as Sean's MongoDB version:
- Same endpoints
- Same JSON format
- Same responses

Just change the base URL from Sean's server to:
```
http://localhost:5001
```

## Next Steps

1. ✅ Database initialized
2. ✅ API server running
3. ✅ MCP tools available
4. ⏳ Connect to CropClient v8.9
5. ⏳ Integrate with Gus/Phi-3
6. ⏳ Deploy to production

## Production Deployment

SQLite file is portable - just copy `cropclient.db` to production server along with the API server code.

For high concurrency, consider SQLite in WAL mode:
```sql
PRAGMA journal_mode=WAL;
```

## Testing

Run full API test suite:
```bash
npm run api &
node test-api.js
```

---

**Steve's Philosophy:** "JSON is the fruit of the vine" - SQLite gives us that juice instantly, portably, and reliably. No outlaw code. Everything has a purpose and a place.
